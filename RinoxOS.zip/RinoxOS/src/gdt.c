/* gdt.c - Функции для настройки Global Descriptor Table */

#include <stddef.h>

// Структура для одной записи в GDT (8 байт)
struct gdt_entry_struct {
    unsigned short limit_low;
    unsigned short base_low;
    unsigned char  base_middle;
    unsigned char  access;
    unsigned char  granularity;
    unsigned char  base_high;
} __attribute__((packed));

// Структура для указателя на GDT (6 байт), который мы передадим процессору
struct gdt_ptr_struct {
    unsigned short limit; // Размер GDT
    unsigned int   base;  // Адрес начала GDT
} __attribute__((packed));

// Наши GDT-записи: NULL, Код, Данные
struct gdt_entry_struct gdt_entries[3];
struct gdt_ptr_struct   gdt_ptr;

// Функция для установки одной записи в GDT
void gdt_set_gate(int num, unsigned int base, unsigned int limit, unsigned char access, unsigned char gran) {
    gdt_entries[num].base_low    = (base & 0xFFFF);
    gdt_entries[num].base_middle = (base >> 16) & 0xFF;
    gdt_entries[num].base_high   = (base >> 24) & 0xFF;

    gdt_entries[num].limit_low   = (limit & 0xFFFF);
    gdt_entries[num].granularity = (limit >> 16) & 0x0F;
    gdt_entries[num].granularity |= gran & 0xF0;
    gdt_entries[num].access      = access;
}

// Основная функция инициализации GDT
void gdt_init() {
    gdt_ptr.limit = (sizeof(struct gdt_entry_struct) * 3) - 1;
    gdt_ptr.base  = (unsigned int)&gdt_entries;

    // NULL-дескриптор
    gdt_set_gate(0, 0, 0, 0, 0);
    // Сегмент Кода: база 0, лимит 4GB, доступ 0x9A, гранулярность 0xCF
    gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);
    // Сегмент Данных: то же самое
    gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF);

    // Вызываем внешнюю ассемблерную функцию для загрузки нашей GDT
    extern void gdt_flush(unsigned int);
    gdt_flush((unsigned int)&gdt_ptr);
}
