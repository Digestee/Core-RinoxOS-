/* kernel.c - Ядро RinoxOS с обработкой прерываний от клавиатуры */
#include <stddef.h>

// --- Объявления внешних функций ---
extern void gdt_init();
extern void idt_init();
extern void keyboard_handler();

// --- Встроенная ассемблерная функция для записи в порт ---
static inline void outb(unsigned short port, unsigned char val) {
    asm volatile ( "outb %0, %1" : : "a"(val), "Nd"(port) );
}

// --- Драйвер экрана ---
volatile unsigned short* vga_buffer = (unsigned short*)0xB8000;
int vga_x = 0; int vga_y = 0;
void print_char(char c) {
    if (c == '\b') {
        if (vga_x > 0) {
            vga_x--;
            vga_buffer[vga_y * 80 + vga_x] = (unsigned short)' ' | 0x0F00;
        }
    } else if (c == '\n') {
        vga_x = 0;
        vga_y++;
    } else {
        vga_buffer[vga_y * 80 + vga_x] = (unsigned short)c | 0x0F00;
        vga_x++;
    }
    if (vga_x >= 80) { vga_x = 0; vga_y++; }
}
void print_string(const char* str) { for (int i = 0; str[i] != '\0'; i++) print_char(str[i]); }
void clear_screen() { for (int i = 0; i < 80 * 25; i++) vga_buffer[i] = (unsigned short)' ' | 0x0F00; vga_x = 0; vga_y = 0; }


// --- Главный обработчик прерываний ---
struct regs {
    unsigned int gs, fs, es, ds;
    unsigned int edi, esi, ebp, esp, ebx, edx, ecx, eax;
    unsigned int int_no, err_code;
    unsigned int eip, cs, eflags, useresp, ss;
};

void isr_handler(struct regs *r) {
    if (r->int_no == 33) { // Клавиатура
        keyboard_handler();
    }
    
    // Посылаем сигнал End-Of-Interrupt (EOI) контроллеру прерываний,
    // чтобы он знал, что мы закончили обработку, и мог присылать новые.
    if (r->int_no >= 40) {
        outb(0xA0, 0x20); // Посылаем EOI ведомому PIC
    }
    outb(0x20, 0x20); // Посылаем EOI ведущему PIC
}


// --- Основная функция ядра ---
void kmain(void) {
    clear_screen();
    gdt_init();
    idt_init();
    print_string("RinoxOS is running! Type something...\n");
    
    // Разрешаем процессору обрабатывать прерывания
    asm volatile ("sti");

    // Бесконечный цикл ожидания прерываний
    for(;;);
}
