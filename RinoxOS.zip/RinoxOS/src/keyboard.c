/* keyboard.c - Драйвер для PS/2 клавиатуры */

#include <stdbool.h>

// Объявляем функции, которые нам понадобятся
extern void print_char(char c);

// Функция для чтения из порта
static inline unsigned char inb(unsigned short port) {
    unsigned char ret;
    asm volatile ( "inb %1, %0" : "=a"(ret) : "Nd"(port) );
    return ret;
}

// Таблица раскладки для скан-кодов (только US-раскладка)
unsigned char kbdus[128] =
{
    0,  27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
    '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
    0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0,
    '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0, '*',
    0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    '7', '8', '9', '-', '4', '5', '6', '+', '1', '2', '3', '0', '.'
};

// Обработчик прерывания от клавиатуры
void keyboard_handler() {
    unsigned char scancode;

    // Читаем скан-код из порта данных клавиатуры
    scancode = inb(0x60);

    // Если клавиша нажата (старший бит 0)
    if (!(scancode & 0x80)) {
        // Преобразуем скан-код в ASCII и выводим на экран
        print_char(kbdus[scancode]);
    }
}
